import { Component } from '@angular/core';

@Component({
  selector: 'app-assign-roles-list',
  templateUrl: './assign-roles-list.component.html',
  styleUrls: ['./assign-roles-list.component.scss']
})
export class AssignRolesListComponent {

}

import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from '../DashboardService';


@Component({
  selector: 'app-add-career-path',
  templateUrl: './add-career-path.component.html',
  styleUrls: ['./add-career-path.component.scss']
})
export class AddCareerPathComponent {


  constructor(private route: ActivatedRoute, private router: Router,private dashboardService: DashboardService) {
      
    }

    ngOnInit(): void {
      this.dashboardService.initDashboardFeatures();
    }

}

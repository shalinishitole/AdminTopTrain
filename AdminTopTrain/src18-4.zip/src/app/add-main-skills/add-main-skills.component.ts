import { Component } from '@angular/core';

@Component({
  selector: 'app-add-main-skills',
  templateUrl: './add-main-skills.component.html',
  styleUrls: ['./add-main-skills.component.scss']
})
export class AddMainSkillsComponent {

}

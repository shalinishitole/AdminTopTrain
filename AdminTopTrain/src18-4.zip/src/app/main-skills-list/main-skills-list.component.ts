import { Component } from '@angular/core';

@Component({
  selector: 'app-main-skills-list',
  templateUrl: './main-skills-list.component.html',
  styleUrls: ['./main-skills-list.component.scss']
})
export class MainSkillsListComponent {

}

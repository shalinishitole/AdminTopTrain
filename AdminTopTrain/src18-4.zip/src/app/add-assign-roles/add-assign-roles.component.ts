import { Component } from '@angular/core';

@Component({
  selector: 'app-add-assign-roles',
  templateUrl: './add-assign-roles.component.html',
  styleUrls: ['./add-assign-roles.component.scss']
})
export class AddAssignRolesComponent {

}

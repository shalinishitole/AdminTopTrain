import { Component } from '@angular/core';

@Component({
  selector: 'app-add-toptrain-info',
  templateUrl: './add-toptrain-info.component.html',
  styleUrls: ['./add-toptrain-info.component.scss']
})
export class AddToptrainInfoComponent {

}

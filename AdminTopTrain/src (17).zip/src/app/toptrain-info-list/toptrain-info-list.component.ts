import { Component } from '@angular/core';

@Component({
  selector: 'app-toptrain-info-list',
  templateUrl: './toptrain-info-list.component.html',
  styleUrls: ['./toptrain-info-list.component.scss']
})
export class ToptrainInfoListComponent {

}

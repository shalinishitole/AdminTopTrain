import { Component } from '@angular/core';

@Component({
  selector: 'app-add-career-path',
  templateUrl: './add-career-path.component.html',
  styleUrls: ['./add-career-path.component.scss']
})
export class AddCareerPathComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-add-sub-skills',
  templateUrl: './add-sub-skills.component.html',
  styleUrls: ['./add-sub-skills.component.scss']
})
export class AddSubSkillsComponent {

}

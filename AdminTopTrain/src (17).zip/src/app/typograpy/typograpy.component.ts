import { Component } from '@angular/core';

@Component({
  selector: 'app-typograpy',
  templateUrl: './typograpy.component.html',
  styleUrls: ['./typograpy.component.scss']
})
export class TypograpyComponent {

}

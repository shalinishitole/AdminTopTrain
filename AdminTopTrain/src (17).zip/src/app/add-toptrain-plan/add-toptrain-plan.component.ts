import { Component } from '@angular/core';

@Component({
  selector: 'app-add-toptrain-plan',
  templateUrl: './add-toptrain-plan.component.html',
  styleUrls: ['./add-toptrain-plan.component.scss']
})
export class AddToptrainPlanComponent {

}

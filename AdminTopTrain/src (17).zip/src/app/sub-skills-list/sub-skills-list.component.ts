import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-skills-list',
  templateUrl: './sub-skills-list.component.html',
  styleUrls: ['./sub-skills-list.component.scss']
})
export class SubSkillsListComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-career-path-list',
  templateUrl: './career-path-list.component.html',
  styleUrls: ['./career-path-list.component.scss']
})
export class CareerPathListComponent {

}

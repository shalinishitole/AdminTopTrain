import { Component } from '@angular/core';

@Component({
  selector: 'app-ui-element',
  templateUrl: './ui-element.component.html',
  styleUrls: ['./ui-element.component.scss']
})
export class UiElementComponent {

}

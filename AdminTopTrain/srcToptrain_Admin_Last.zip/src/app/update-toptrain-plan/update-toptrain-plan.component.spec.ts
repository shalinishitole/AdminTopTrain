import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateToptrainPlanComponent } from './update-toptrain-plan.component';

describe('UpdateToptrainPlanComponent', () => {
  let component: UpdateToptrainPlanComponent;
  let fixture: ComponentFixture<UpdateToptrainPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateToptrainPlanComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateToptrainPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

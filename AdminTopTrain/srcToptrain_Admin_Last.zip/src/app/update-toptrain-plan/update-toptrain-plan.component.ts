import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-update-toptrain-plan',
  templateUrl: './update-toptrain-plan.component.html',
  styleUrls: ['./update-toptrain-plan.component.scss']
})
export class UpdateToptrainPlanComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

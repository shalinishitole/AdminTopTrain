import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { WebService } from '../Service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Industry } from '../Class';

@Component({
  selector: 'app-industry-list',
  templateUrl: './industry-list.component.html',
  styleUrls: ['./industry-list.component.scss']
})
export class IndustryListComponent {
  industry:Industry
  industryList:any[]
  
  constructor(private router: Router,  private http: HttpClient, private service: WebService, private dashboardService: DashboardService) {
    this.industryList=[];
    this.industry=new Industry()
   }

   Delete(IndustryId) {
    // Show confirmation dialog
    if (confirm("Are you sure you want to delete this industry?")) {
      // If user confirms, proceed with delete operation
      this.service.GetIndustryById(IndustryId).subscribe((result) => {
        this.industry = result;
        console.log(this.industry);
  
        this.industry.Status = "InActive";
  
        this.service.UpdateIndustry(this.industry).subscribe((result) => {
          console.log("hhh", result);
          if (result == 0) {
            alert("Something went wrong! Please try again.");
          } else {
            alert('Delete Successfully.');
            this.GetAllIndustry();
          }
        });
      });
    }
  }

  
  Edit(IndustryId): void{
    try {
      this.router.navigateByUrl("/UpdateIndustry/" + IndustryId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }
  View(IndustryId): void{
    try {
      this.router.navigateByUrl("/ViewIndustry/" + IndustryId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }

  GetAllIndustry(){
    this.service.GetAllIndustry().subscribe((result) => {
      this.industryList=[]
      console.log(result);
      for(let data of result)
      {
        if (data.Status === "Active") {
          this.industryList.push(data);
        }
          // this.industryList.push(data);   
      }     
           console.log(this.industryList);
    });
  }
  ngOnInit(): void {
  this.GetAllIndustry()
  this.dashboardService.initDashboardFeatures();
  }

}
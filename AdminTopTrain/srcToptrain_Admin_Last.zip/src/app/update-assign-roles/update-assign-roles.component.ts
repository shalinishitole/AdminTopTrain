import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-update-assign-roles',
  templateUrl: './update-assign-roles.component.html',
  styleUrls: ['./update-assign-roles.component.scss']
})
export class UpdateAssignRolesComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

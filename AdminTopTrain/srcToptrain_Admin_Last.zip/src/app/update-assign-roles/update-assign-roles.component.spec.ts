import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAssignRolesComponent } from './update-assign-roles.component';

describe('UpdateAssignRolesComponent', () => {
  let component: UpdateAssignRolesComponent;
  let fixture: ComponentFixture<UpdateAssignRolesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateAssignRolesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateAssignRolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-add-toptrain-info',
  templateUrl: './add-toptrain-info.component.html',
  styleUrls: ['./add-toptrain-info.component.scss']
})
export class AddToptrainInfoComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

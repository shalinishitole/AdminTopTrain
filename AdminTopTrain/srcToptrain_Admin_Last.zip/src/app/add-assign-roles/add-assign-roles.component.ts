import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-add-assign-roles',
  templateUrl: './add-assign-roles.component.html',
  styleUrls: ['./add-assign-roles.component.scss']
})
export class AddAssignRolesComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-toptrain-plan-list',
  templateUrl: './toptrain-plan-list.component.html',
  styleUrls: ['./toptrain-plan-list.component.scss']
})
export class ToptrainPlanListComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

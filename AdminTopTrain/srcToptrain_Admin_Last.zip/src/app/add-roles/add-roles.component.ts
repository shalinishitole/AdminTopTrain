import { Component } from '@angular/core';
import { Role } from '../Class'; // Assuming you have a Role class defined
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
import { DashboardService } from '../DashboardService';


@Component({
  selector: 'app-add-roles',
  templateUrl: './add-roles.component.html',
  styleUrls: ['./add-roles.component.scss']
})
export class AddRolesComponent {

  role: Role;

  constructor(private router: Router,
    private http: HttpClient,
    private service: WebService,
    private dashboardService: DashboardService) {

    this.role = new Role();

  }
  
  onSubmit() {
    console.log("role", this.role);
    this.role.Status = "Active";
    this.service.AddRole(this.role).subscribe((result: number) => {
      if (result > 0) {
        alert('Role saved successfully.');
      } else {
        alert("Something went wrong! Please try again.");
      }
    });
  }

  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}
import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { Industry } from '../Class';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';

@Component({
  selector: 'app-update-industry',
  templateUrl: './update-industry.component.html',
  styleUrls: ['./update-industry.component.scss']
})
export class UpdateIndustryComponent {

  IndustryId:any
  industry:Industry
 
  
 // doctors: any;
  updateindustry: any;
  constructor(private route: ActivatedRoute,private router: Router,
    private http: HttpClient,
    private service: WebService,private dashboardService: DashboardService) { 
      this.industry = new Industry();
      this.route.params.subscribe((params) => {
        this.IndustryId = params['IndustryId'];
   
      
      // this.aboutlist = [];
  
        this.service.GetIndustryById(this.IndustryId).subscribe((result) => {
       
          this.industry= result;
          console.log("industry", this.industry);
  
      });
     });
    }
 
    onSubmit(){
      debugger;
            console.log(this.industry);
            this.service.UpdateIndustry(this.industry).subscribe((result) => {
              console.log("hhh",result);
              if (result == 0) {
                alert("Something went wrong! Please try again.");
              } 
              else {
                
                  alert('Saved Successfully.');
              
              }
                        
             });
             

            }
            ngOnInit(): void {
              this.dashboardService.initDashboardFeatures();
             }

}
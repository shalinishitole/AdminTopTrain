import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  constructor(private route: ActivatedRoute,private router: Router) { }
  // logout(){
  //   // window.location.href="https://admintoptrain.prismplusts.com/#/Login";
  //   this.router.navigateByUrl('/http://localhost:4200/#/Login');
    
  // }

  Logout(){
    sessionStorage.clear()
    this.router.navigateByUrl("/Login");
  }
}

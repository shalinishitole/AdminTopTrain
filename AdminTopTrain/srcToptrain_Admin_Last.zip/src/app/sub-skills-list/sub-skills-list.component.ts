import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { WebService } from '../Service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { SubSkill } from '../Class';

@Component({
  selector: 'app-sub-skills-list',
  templateUrl: './sub-skills-list.component.html',
  styleUrls: ['./sub-skills-list.component.scss']
})
export class SubSkillsListComponent {
  subSkill:SubSkill
  subSkillList: any[] = [];
  
  constructor(private router: Router, private http: HttpClient, private service: WebService, private dashboardService: DashboardService) {
    this.subSkill=new SubSkill()
  }

  Delete(SubSkillId) {
    // Show confirmation dialog
    if (confirm("Are you sure you want to delete this sub skill?")) {
      // If user confirms, proceed with delete operation
      this.service.GetSubSkillById(SubSkillId).subscribe((result) => {
        this.subSkill = result;
        console.log(this.subSkill);
  
        this.subSkill.Status = "InActive";
  
        this.service.UpdateSubSkill(this.subSkill).subscribe((result) => {
          console.log("hhh", result);
          if (result == 0) {
            alert("Something went wrong! Please try again.");
          } else {
            alert('Delete Successfully.');
            this.GetAllSubSkills();
          }
        });
      });
    }
  }
  

  Edit(SubSkillId): void {
    try {
      this.router.navigateByUrl("/UpdateSubSkill/" + SubSkillId);
    } catch (error) {
      alert("Error: " + error);
    } 
  }

  View(SubSkillId): void {
    try {
      this.router.navigateByUrl("/ViewSubSkill/" + SubSkillId);
    } catch (error) {
      alert("Error: " + error);
    } 
  }

  GetAllSubSkills() {
    this.service.GetAllSubSkill().subscribe((result) => {
      this.subSkillList = [];
      console.log(result);
      for (let data of result) {
        if (data.Status === "Active") {
          this.subSkillList.push(data); 
        }       
      }     
      console.log(this.subSkillList);
    });
  }

  ngOnInit(): void {
    this.GetAllSubSkills();
    this.dashboardService.initDashboardFeatures();
  }
}
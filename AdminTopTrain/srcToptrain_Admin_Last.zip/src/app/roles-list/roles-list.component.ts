import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { WebService } from '../Service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Role } from '../Class';
@Component({
  selector: 'app-roles-list',
  templateUrl: './roles-list.component.html',
  styleUrls: ['./roles-list.component.scss']
})
export class RolesListComponent {
  role:Role
  roleList: any[];
  
  constructor(private router: Router, private http: HttpClient, private service: WebService, private dashboardService: DashboardService) {
    this.roleList = [];
    this.role=new Role()
  }

  Delete(RoleId) {
    // Show confirmation dialog
    if (confirm("Are you sure you want to delete this role?")) {
      // If user confirms, proceed with delete operation
      this.service.GetRoleById(RoleId).subscribe((result) => {
        this.role = result;
        console.log(this.role);
  
        this.role.Status = "InActive";
  
        this.service.UpdateRole(this.role).subscribe((result) => {
          console.log("hhh", result);
          if (result == 0) {
            alert("Something went wrong! Please try again.");
          } else {
            alert('Delete Successfully.');
            this.GetAllRoles();
          }
        });
      });
    }
  }
  

  Edit(RoleId): void {
    try {
      this.router.navigateByUrl("/UpdateRole/" + RoleId);
    } catch (error) {
      alert("Error: " + error);
    } 
  }

  View(RoleId): void {
    try {
      this.router.navigateByUrl("/ViewRole/" + RoleId);
    } catch (error) {
      alert("Error: " + error);
    } 
  }

  GetAllRoles() {
    this.service.GetAllRole().subscribe((result) => {
      this.roleList = [];
      console.log(result);
      for (let data of result) {
        if (data.Status === "Active") {
          this.roleList.push(data);   
        }   
      }     
      console.log(this.roleList,"this.roleList");
    });
  }

  ngOnInit(): void {
    this.GetAllRoles();
    this.dashboardService.initDashboardFeatures();
  }
}
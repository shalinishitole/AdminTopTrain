import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
import { CarrerPath, Industry } from '../Class';

@Component({
  selector: 'app-update-career-path',
  templateUrl: './update-career-path.component.html',
  styleUrls: ['./update-career-path.component.scss']
})
export class UpdateCareerPathComponent {

  CarrerPathId: any
  carrerPath: CarrerPath
  industry: Industry

  industrylist: any[] = []

  constructor(private route: ActivatedRoute, private router: Router,
    private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.carrerPath = new CarrerPath();
    this.carrerPath.industry = new Industry();
    this.GetAllIndustry();
    this.route.params.subscribe((params) => {
      this.CarrerPathId = params['CarrerPathId'];


      // this.aboutlist = [];

      this.service.GetCarrerPathById(this.CarrerPathId).subscribe((result) => {

        this.carrerPath = result;
        console.log("industry", this.carrerPath);

      });
    });
  }

  GetAllIndustry() {
    this.service.GetAllIndustry().subscribe((result) => {
      console.log(result);
      for (let data of result) {
        this.industrylist.push(data);
      }
      console.log("GetAllIndustry", this.industrylist);
    });
  }
  OnSubmit() {
    debugger;
    console.log(this.carrerPath);
    this.service.UpdateCarrerPath(this.carrerPath).subscribe((result) => {
      console.log("hhh", result);
      if (result == 0) {
        alert("Something went wrong! Please try again.");
      }
      else {

        alert('Saved Successfully.');

      }

    });


  }
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }

}
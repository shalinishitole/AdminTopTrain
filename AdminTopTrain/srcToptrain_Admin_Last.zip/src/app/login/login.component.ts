import { Component } from '@angular/core';
import { AdminRegistration } from '../Class';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  searchText1: any
  searchText2: any
  userid:any
  adminRegistration:AdminRegistration

  constructor( private router: Router,private http: HttpClient,private service: WebService) {
    this.adminRegistration = new AdminRegistration();
    }


    OnSubmit() {
      this.service.Loginc(this.searchText1, this.searchText2).subscribe((result) => {
        sessionStorage.setItem('SID', result.AdminRegistrationId);
        this.userid = JSON.parse(sessionStorage.getItem('SID'));

        console.log("userid", this.userid);
        if (this.userid == 0) {
          // alert("Invalid Email and Password.")
          alert('Invalid Email or Password.');
        }
        else {
          alert("Login Successfully");
          this.router.navigateByUrl("/Dashboard") ;
        }
      })


    }

}
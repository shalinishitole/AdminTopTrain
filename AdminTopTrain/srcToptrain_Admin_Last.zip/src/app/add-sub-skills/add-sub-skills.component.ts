import { Component } from '@angular/core';
import { Industry, MainSkill, SubSkill } from '../Class';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from '../DashboardService';

import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';


@Component({
  selector: 'app-add-sub-skills',
  templateUrl: './add-sub-skills.component.html',
  styleUrls: ['./add-sub-skills.component.scss']
})
export class AddSubSkillsComponent {


  subSkill: SubSkill
  industry: Industry
  mainSkill: MainSkill
  industryList: any[]=[]
  mainSkillList: any[]=[]
  uploadResult: any;
  filesToUpload: Array<File>;
  selectedFileNames: string[] = [];

  constructor(private router: Router,
    private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.subSkill = new SubSkill();
    this.subSkill.industry = new Industry();
    this.subSkill.mainSkill = new MainSkill();

  }
  OnSubmit() {
    console.log("subSkill", this.subSkill);
    this.subSkill.Status="Active"
    this.service.AddSubSkill(this.subSkill).subscribe((result) => {
      if (result > 0) {
          alert('Saved Successfully.');
      }
      else {
        alert("Something went wrong! Please try again.")
      }
    });
  }


  IndustryChange(event) {
    console.log('UserId:', event.target.value);
    this.subSkill.industry.IndustryId = event.target.value;
    this.GetAllMainSkill();

  }

  GetAllMainSkill() {
    let tmp = [];
    this.service.GetAllMainSkill().subscribe((result) => {
      for (let data of result) {
        if (data.Status === "Active") {
          tmp.push(data);
        } 
      }
      console.log("tmp",tmp);
      console.log("this.subSkill.industry.IndustryId",this.subSkill.industry.IndustryId);
     
      let list = tmp.filter(
        (tmp) => tmp.industry.IndustryId == this.subSkill.industry.IndustryId)
      this.mainSkillList = list;
      console.log(this.mainSkillList,"this.mainSkillList");
    });
  }
  GetAllIndustry() {
    this.industryList = []
    this.service.GetAllIndustry().subscribe((result) => {
      for (let data of result) {
        if (data.Status === "Active") {
          this.industryList.push(data);
        } 
      }
      console.log("mainCategoryList", this.industryList);
    });
  }
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
    this.GetAllIndustry();
  }

}

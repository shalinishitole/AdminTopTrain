import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-add-toptrain-plan',
  templateUrl: './add-toptrain-plan.component.html',
  styleUrls: ['./add-toptrain-plan.component.scss']
})
export class AddToptrainPlanComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

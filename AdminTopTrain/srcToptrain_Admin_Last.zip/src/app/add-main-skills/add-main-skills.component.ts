import { Component } from '@angular/core';
import { Industry, MainSkill } from '../Class';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from '../DashboardService';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';

@Component({
  selector: 'app-add-main-skills',
  templateUrl: './add-main-skills.component.html',
  styleUrls: ['./add-main-skills.component.scss']
})
export class AddMainSkillsComponent {


  mainSkill: MainSkill
  industry: Industry

  industrylist: any[] = []

  constructor(private route: ActivatedRoute, private router: Router, private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.mainSkill = new MainSkill();
    this.mainSkill.industry = new Industry();
    this.GetAllIndustry();
  }

  OnSubmit() {
    console.log("prop", this.mainSkill);
    this.mainSkill.Status="Active"
    // this.carrerPath.industry.IndustryId = 1
    this.service.AddMainSkill(this.mainSkill).subscribe((result) => {
      if (result > 0) {


        alert('Saved Successfully.');

      }
      else {
        alert("Something went wrong! Please try again.")
      }
    });

  }

  GetAllIndustry() {
    this.service.GetAllIndustry().subscribe((result) => {
      console.log(result);
      for (let data of result) {
        if (data.Status === "Active") {
          this.industrylist.push(data);
        }  
      }
      console.log("GetAllIndustry", this.industrylist);
    });
  }


  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }

}

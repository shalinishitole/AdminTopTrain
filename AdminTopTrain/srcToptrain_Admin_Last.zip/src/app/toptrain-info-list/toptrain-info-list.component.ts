import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-toptrain-info-list',
  templateUrl: './toptrain-info-list.component.html',
  styleUrls: ['./toptrain-info-list.component.scss']
})
export class ToptrainInfoListComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

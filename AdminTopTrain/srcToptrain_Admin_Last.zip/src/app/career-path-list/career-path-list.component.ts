import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { WebService } from '../Service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CarrerPath } from '../Class';

@Component({
  selector: 'app-career-path-list',
  templateUrl: './career-path-list.component.html',
  styleUrls: ['./career-path-list.component.scss']
})
export class CareerPathListComponent {
  carrerPath:CarrerPath

  carrerPathList:any[]=[]
  
  constructor(private router: Router,  private http: HttpClient, private service: WebService, private dashboardService: DashboardService) {
    this.carrerPath=new CarrerPath()
   }

   Delete(CarrerPathId) {
    // Show confirmation dialog
    if (confirm("Are you sure you want to delete this career path?")) {
      // If user confirms, proceed with delete operation
      this.service.GetCarrerPathById(CarrerPathId).subscribe((result) => {
        this.carrerPath = result;
        console.log(this.carrerPath);
  
        this.carrerPath.Status = "InActive";
  
        this.service.UpdateCarrerPath(this.carrerPath).subscribe((result) => {
          console.log("hhh", result);
          if (result == 0) {
            alert("Something went wrong! Please try again.");
          } else {
            alert('Delete Successfully.');
            this.GetAllCarrerPath();
          }
        });
      });
    }
  }
  
  Edit(CarrerPathId): void{
    try {
      this.router.navigateByUrl("/UpdateCareerPath/" + CarrerPathId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }
  View(CarrerPathId): void{
    try {
      this.router.navigateByUrl("/ViewDestinations/" + CarrerPathId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }

  GetAllCarrerPath(){
    this.service.GetAllCarrerPath().subscribe((result) => {
      this.carrerPathList=[]
      console.log(result);
      for(let data of result)
      {
        if (data.Status === "Active") {
          this.carrerPathList.push(data);   
        }
      }     
           console.log(this.carrerPathList);
    });
  }
  ngOnInit(): void {
  this.GetAllCarrerPath()
  this.dashboardService.initDashboardFeatures();
  }

}
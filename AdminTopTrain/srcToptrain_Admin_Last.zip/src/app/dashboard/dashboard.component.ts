import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
declare let body: JQuery<HTMLElement>;
import * as bootstrap from 'bootstrap';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  UId:any
  constructor(private route: ActivatedRoute, ) { 
    // this.route.params.subscribe((params) => {
    //   this.UId = JSON.parse(sessionStorage.getItem('SID'));

    // });
  }

  ngOnInit(): void {
    $('[data-toggle="minimize"]').on("click", function(this: HTMLElement) {
      if ((body.hasClass('sidebar-toggle-display')) || (body.hasClass('sidebar-absolute'))) {
        body.toggleClass('sidebar-hidden');
      } else {
        body.toggleClass('sidebar-icon-only');
      }
    });
  }



}

import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { WebService } from '../Service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { MainSkill } from '../Class';

@Component({
  selector: 'app-main-skills-list',
  templateUrl: './main-skills-list.component.html',
  styleUrls: ['./main-skills-list.component.scss']
})
export class MainSkillsListComponent {

  mainSkill:MainSkill
 mainSkillList:any[]=[]
  
  constructor(private router: Router,  private http: HttpClient, private service: WebService, private dashboardService: DashboardService) {
    this.mainSkill=new MainSkill()
   }

   Delete(MainSkillId) {
    // Show confirmation dialog
    if (confirm("Are you sure you want to delete this main skill?")) {
      // If user confirms, proceed with delete operation
      this.service.GetMainSkillById(MainSkillId).subscribe((result) => {
        this.mainSkill = result;
        console.log(this.mainSkill);
  
        this.mainSkill.Status = "InActive";
  
        this.service.UpdateMainSkill(this.mainSkill).subscribe((result) => {
          console.log("hhh", result);
          if (result == 0) {
            alert("Something went wrong! Please try again.");
          } else {
            alert('Delete Successfully.');
            this.GetAllMainSkill();
          }
        });
      });
    }
  }
  
  Edit(MainSkillId): void{
    try {
      this.router.navigateByUrl("/UpdateMainSkill/" + MainSkillId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }
  View(MainSkillId): void{
    try {
      this.router.navigateByUrl("/ViewDestinations/" + MainSkillId,);
    } catch (error) {
      alert("certi-" + error);
    } 
  }

  GetAllMainSkill(){
    this.service.GetAllMainSkill().subscribe((result) => {
      this.mainSkillList=[]
      console.log(result);
      for(let data of result)
      {
        if (data.Status === "Active") {
          this.mainSkillList.push(data);
        }        
      }     
           console.log(this.mainSkillList);
    });
  }
  ngOnInit(): void {
  this.GetAllMainSkill()
  this.dashboardService.initDashboardFeatures();
  }

}
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsComponent } from './forms/forms.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { TablesComponent } from './tables/tables.component';
import { ButtonComponent } from './button/button.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { AddIndustryComponent } from './add-industry/add-industry.component';
import { IndustryListComponent } from './industry-list/industry-list.component';
import { AddMainSkillsComponent } from './add-main-skills/add-main-skills.component';
import { MainSkillsListComponent } from './main-skills-list/main-skills-list.component';
import { AddSubSkillsComponent } from './add-sub-skills/add-sub-skills.component';
import { SubSkillsListComponent } from './sub-skills-list/sub-skills-list.component';
import { CareerPathListComponent } from './career-path-list/career-path-list.component';
import { AddCareerPathComponent } from './add-career-path/add-career-path.component';
import { AddAssignRolesComponent } from './add-assign-roles/add-assign-roles.component';
import { AddRolesComponent } from './add-roles/add-roles.component';
import { AddToptrainInfoComponent } from './add-toptrain-info/add-toptrain-info.component';
import { AddToptrainPlanComponent } from './add-toptrain-plan/add-toptrain-plan.component';
import { AssignRolesListComponent } from './assign-roles-list/assign-roles-list.component';
import { RolesListComponent } from './roles-list/roles-list.component';
import { ToptrainInfoListComponent } from './toptrain-info-list/toptrain-info-list.component';
import { ToptrainPlanListComponent } from './toptrain-plan-list/toptrain-plan-list.component';
import { UpdateAssignRolesComponent } from './update-assign-roles/update-assign-roles.component';
import { UpdateCareerPathComponent } from './update-career-path/update-career-path.component';
import { UpdateIndustryComponent } from './update-industry/update-industry.component';
import { UpdateMainSkillsComponent } from './update-main-skills/update-main-skills.component';
import { UpdateRolesComponent } from './update-roles/update-roles.component';
import { UpdateSubSkillsComponent } from './update-sub-skills/update-sub-skills.component';
import { UpdateToptrainInfoComponent } from './update-toptrain-info/update-toptrain-info.component';
import { UpdateToptrainPlanComponent } from './update-toptrain-plan/update-toptrain-plan.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { OtpMatchComponent } from './otp-match/otp-match.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { AuthGuard } from './auth-guard.service';

const routes: Routes = [
  { path: 'Dashboard', component: DashboardComponent , canActivate: [AuthGuard]},
  { path: 'Forms', component: FormsComponent },
  { path: 'Login', component: LoginComponent },
  { path: 'Registration', component: RegistrationComponent },
   { path: 'Tables', component: TablesComponent },
   { path: 'Button', component: ButtonComponent },
   { path: 'Dropdown', component: DropdownComponent },


  //  toptrain Menu sytart
  { path: 'AddIndustry', component: AddIndustryComponent, canActivate: [AuthGuard]},
  { path: 'IndustryList', component: IndustryListComponent , canActivate: [AuthGuard]},
  { path: 'AddMainSkills', component: AddMainSkillsComponent , canActivate: [AuthGuard]},
  { path: 'MainSkillsList', component: MainSkillsListComponent, canActivate: [AuthGuard]},

  { path: 'AddSubSkills', component: AddSubSkillsComponent, canActivate: [AuthGuard]},
  { path: 'SubSkillsList', component: SubSkillsListComponent },
  { path: 'AddRoles', component: AddRolesComponent, canActivate: [AuthGuard]},
  { path: 'RolesList', component: RolesListComponent, canActivate: [AuthGuard]},
  { path: 'AddAssignRoles', component: AddAssignRolesComponent, canActivate: [AuthGuard]},
  { path: 'AssignRolesList', component: AssignRolesListComponent, canActivate: [AuthGuard]},
  { path: 'AddToptrainInfo', component: AddToptrainInfoComponent , canActivate: [AuthGuard]},
  { path: 'ToptrainInfoList', component: ToptrainInfoListComponent , canActivate: [AuthGuard]},
  { path: 'AddToptrainPlan', component: AddToptrainPlanComponent , canActivate: [AuthGuard]},
  { path: 'ToptrainPlanList', component: ToptrainPlanListComponent , canActivate: [AuthGuard]},
  { path: 'AddCareerPath', component: AddCareerPathComponent , canActivate: [AuthGuard]},
  { path: 'CareerPathList', component: CareerPathListComponent , canActivate: [AuthGuard]},

  { path: 'ForgetPassword', component: ForgotPasswordComponent , canActivate: [AuthGuard]},
  { path: 'OtpMatch/:Id', component: OtpMatchComponent , canActivate: [AuthGuard]},
  { path: 'ResetPassword/:Id', component: ResetPasswordComponent, canActivate: [AuthGuard]},
  
  { path: 'UpdateIndustry/:IndustryId', component: UpdateIndustryComponent , canActivate: [AuthGuard]},
  { path: 'UpdateMainSkill/:MainSkillId', component: UpdateMainSkillsComponent, canActivate: [AuthGuard]},
  { path: 'UpdateSubSkill/:SubSkillId', component: UpdateSubSkillsComponent, canActivate: [AuthGuard]},
  { path: 'UpdateRole/:RoleId', component: UpdateRolesComponent, canActivate: [AuthGuard]},
  { path: 'UpdateAssignRoles', component: UpdateAssignRolesComponent , canActivate: [AuthGuard]},
  { path: 'UpdateToptrainInfo', component: UpdateToptrainInfoComponent , canActivate: [AuthGuard]},
  { path: 'UpdateToptrainPlan', component: UpdateToptrainPlanComponent, canActivate: [AuthGuard]},
  { path: 'UpdateCareerPath/:CarrerPathId', component: UpdateCareerPathComponent, canActivate: [AuthGuard]},
  
  { path: '',   redirectTo: '/Login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }

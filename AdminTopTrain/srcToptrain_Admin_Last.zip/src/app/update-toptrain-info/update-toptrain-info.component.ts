import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';

@Component({
  selector: 'app-update-toptrain-info',
  templateUrl: './update-toptrain-info.component.html',
  styleUrls: ['./update-toptrain-info.component.scss']
})
export class UpdateToptrainInfoComponent {
  constructor(private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateToptrainInfoComponent } from './update-toptrain-info.component';

describe('UpdateToptrainInfoComponent', () => {
  let component: UpdateToptrainInfoComponent;
  let fixture: ComponentFixture<UpdateToptrainInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateToptrainInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateToptrainInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

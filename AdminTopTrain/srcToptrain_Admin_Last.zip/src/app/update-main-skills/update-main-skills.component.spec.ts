import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMainSkillsComponent } from './update-main-skills.component';

describe('UpdateMainSkillsComponent', () => {
  let component: UpdateMainSkillsComponent;
  let fixture: ComponentFixture<UpdateMainSkillsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateMainSkillsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateMainSkillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

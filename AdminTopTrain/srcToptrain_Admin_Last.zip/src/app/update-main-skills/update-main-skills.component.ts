import { Component } from '@angular/core';
import { MainSkill } from '../Class';
import { DashboardService } from '../DashboardService';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';


@Component({
  selector: 'app-update-main-skills',
  templateUrl: './update-main-skills.component.html',
  styleUrls: ['./update-main-skills.component.scss']
})
export class UpdateMainSkillsComponent {

  MainSkillId: any
  mainSkill: MainSkill
  industrylist: any[] = []

  constructor(private route: ActivatedRoute, private router: Router,
    private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.mainSkill = new MainSkill();
    this.route.params.subscribe((params) => {
      this.MainSkillId = params['MainSkillId'];
      this.GetAllIndustry();

      // this.aboutlist = [];

      this.service.GetMainSkillById(this.MainSkillId).subscribe((result) => {

        this.mainSkill = result;
        console.log("mainSkill", this.mainSkill);

      });
    });
  }


  GetAllIndustry() {
    this.service.GetAllIndustry().subscribe((result) => {
      console.log(result);
      for (let data of result) {
        this.industrylist.push(data);
      }
      console.log("GetAllIndustry", this.industrylist);
    });
  }

  onSubmit() {
    debugger;
    console.log(this.mainSkill);
    this.service.UpdateMainSkill(this.mainSkill).subscribe((result) => {
      console.log("hhh", result);
      if (result == 0) {
        alert("Something went wrong! Please try again.");
      }
      else {

        alert('Saved Successfully.');

      }

    });


  }
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }

}
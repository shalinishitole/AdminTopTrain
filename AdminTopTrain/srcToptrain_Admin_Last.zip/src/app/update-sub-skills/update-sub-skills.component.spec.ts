import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSubSkillsComponent } from './update-sub-skills.component';

describe('UpdateSubSkillsComponent', () => {
  let component: UpdateSubSkillsComponent;
  let fixture: ComponentFixture<UpdateSubSkillsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateSubSkillsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateSubSkillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

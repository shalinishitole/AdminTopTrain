import { Component } from '@angular/core';
import { Industry, MainSkill, SubSkill } from '../Class';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from '../DashboardService';

import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';

@Component({
  selector: 'app-update-sub-skills',
  templateUrl: './update-sub-skills.component.html',
  styleUrls: ['./update-sub-skills.component.scss']
})
export class UpdateSubSkillsComponent {


  subSkill: SubSkill
  industry: Industry
  mainSkill: MainSkill
  industryList: any[]=[]
  mainSkillList: any[]=[]
  uploadResult: any;
  filesToUpload: Array<File>;
  selectedFileNames: string[] = [];
  SubSkillId:any

  constructor(private route: ActivatedRoute,private router: Router,
    private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.subSkill = new SubSkill();
    this.subSkill.industry = new Industry();
    this.subSkill.mainSkill = new MainSkill();
    this.route.params.subscribe((params) => {
      this.SubSkillId = params['SubSkillId'];
      this.GetAllIndustry();

      // this.aboutlist = [];

      this.service.GetSubSkillById(this.SubSkillId).subscribe((result) => {

        this.subSkill = result;
        console.log("subSkill", this.subSkill);

      });
    });

  }
  OnSubmit() {
    this.service.UpdateSubSkill(this.subSkill).subscribe((result) => {
      console.log("hhh", result);
      if (result == 0) {
        alert("Something went wrong! Please try again.");
      }
      else {

        alert('Saved Successfully.');

      }

    });
  }


  IndustryChange(event) {
    console.log('UserId:', event.target.value);
    this.subSkill.industry.IndustryId = event.target.value;
    this.GetAllMainSkill();

  }

  // GetAllSubCategory() {
  //   this.subCategoryList = []
  //   this.service.GetAllSubCategory().subscribe((result) => {
  //     for (let data of result) {
  //       this.subCategoryList.push(data);
  //     }
  //     console.log("subCategoryList", this.subCategoryList);
  //   });
  // }
  GetAllMainSkill() {
    let tmp = [];
    this.service.GetAllMainSkill().subscribe((result) => {
      for (let data of result) {
        tmp.push(data);
      }
      console.log("tmp",tmp);
      console.log("this.subSkill.industry.IndustryId",this.subSkill.industry.IndustryId);
     
      let list = tmp.filter(
        (tmp) => tmp.industry.IndustryId == this.subSkill.industry.IndustryId)
      this.mainSkillList = list;
      console.log(this.mainSkillList,"this.mainSkillList");
    });
  }
  GetAllIndustry() { 
    this.service.GetAllIndustry().subscribe((result) => {
      this.industryList = []
      for (let data of result) {
        this.industryList.push(data);
      }
      console.log("industryList", this.industryList);
    });
  }
  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
    this.GetAllIndustry();
    this.GetAllMainSkill()
  }

}

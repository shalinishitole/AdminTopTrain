import { Component } from '@angular/core';
import { DashboardService } from '../DashboardService';
import { Role } from '../Class'; // Assuming you have a 'Role' class similar to the 'Industry' class
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
@Component({
  selector: 'app-update-roles',
  templateUrl: './update-roles.component.html',
  styleUrls: ['./update-roles.component.scss']
})
export class UpdateRolesComponent {

  RoleId: any;
  role: Role;
  
  constructor(private route: ActivatedRoute, private router: Router,
    private http: HttpClient,
    private service: WebService, private dashboardService: DashboardService) {
    this.role = new Role();
    this.route.params.subscribe((params) => {
      this.RoleId = params['RoleId'];
  
      this.service.GetRoleById(this.RoleId).subscribe((result) => {
        this.role = result;
        console.log("Role", this.role);
      });
    });
  }

  onSubmit() {
    console.log(this.role);
    this.service.UpdateRole(this.role).subscribe((result) => {
      console.log(result);
      if (result == 0) {
        alert("Something went wrong! Please try again.");
      } else {
        alert('Saved Successfully.');
      }
    });
  }

  ngOnInit(): void {
    this.dashboardService.initDashboardFeatures();
  }
}